###############################################################################
#
# Nederlandse (nl_NL) taalspecifieke functies voor getallen, tijd en
# frequenties. Dit bestand wordt na events.d/locale.tcl geladen en
# overschrijft alleen de functies die in het Nederlands anders werken.
#
# Verwachte clips in Default/: 0-99 als hele woorden (bijv. 21 =
# "eenentwintig"), 100-900, decimal, plus, minus, hours ("uur"),
# over, voor, half, kwart, Hz, kHz, MHz, GHz.
#
###############################################################################


#
# Zeg een getal van twee cijfers (00 - 99).
# "0x" wordt cijfer voor cijfer gezegd ("nul vijf"), "ox" alleen als het
# tweede cijfer. Alle andere getallen als één woord ("zevenenveertig").
#
proc playTwoDigitNumber {number} {
  if {[string length $number] != 2} {
    printWarning "Function playTwoDigitNumber received a non two digit number: $number";
    return;
  }

  set first [string index $number 0];
  if {$first == "0"} {
    playMsg "Default" "0";
    playMsg "Default" [string index $number 1];
  } elseif {$first == "o"} {
    playMsg "Default" [string index $number 1];
  } else {
    playMsg "Default" $number;
  }
}


#
# Zeg een getal van drie cijfers (000 - 999), zonder "en":
# 245 = "tweehonderd" "vijfenveertig".
#
proc playThreeDigitNumber {number} {
  if {[string length $number] != 3} {
    printWarning "Function playThreeDigitNumber received a non three digit number: $number";
    return;
  }

  set first [string index $number 0];
  if {($first == "0") || ($first == "o")} {
    spellNumber $number
  } else {
    playMsg "Default" "${first}00";
    if {[string index $number 1] != "0"} {
      playTwoDigitNumber [string range $number 1 2];
    } elseif {[string index $number 2] != "0"} {
      playMsg "Default" [string index $number 2];
    }
  }
}


#
# Zeg een getal van vier cijfers (1000 - 9999): 1010 = "duizend" "tien",
# 2345 = "twee" "duizend" "driehonderd" "vijfenveertig".
#
proc playFourDigitNumber {number} {
  set first [string index $number 0];
  if {$first != "1"} {
    playMsg "Default" $first;
  }
  playMsg "Default" "1000";
  set rest [string range $number 1 3];
  if {[string index $rest 0] != "0"} {
    playThreeDigitNumber $rest;
  } elseif {[string index $rest 1] != "0"} {
    playTwoDigitNumber [string range $rest 1 2];
  } elseif {[string index $rest 2] != "0"} {
    playMsg "Default" [string index $rest 2];
  }
}


#
# Zeg een getal zo natuurlijk mogelijk. Gelijk aan de standaardversie,
# behalve dat getallen van vier cijfers zonder voorloopnul als
# "duizend ..." worden uitgesproken in plaats van als twee paren.
#
proc playNumber {number} {
  if {![regexp {^\s*([+-])?(\d*)(?:\.(\d+))?\s*$} $number \
        -> sign integer fraction]} {
    printError "Invalid number '$number' in playNumber"
    return
  }

  if {[string length "$integer"] == 0} {
    set integer "0"
  }

  if [expr double("$integer.$fraction") != 0.0] {
    if {$sign == "+"} {
      playMsg "Default" "plus"
    } elseif  {$sign == "-"} {
      playMsg "Default" "minus"
    }
  }

  if {$fraction != ""} {
    playNumber $integer;
    playMsg "Default" "decimal";
    spellNumber $fraction;
    return;
  }

  if {[string length $integer] == 4 && [string index $integer 0] != "0"} {
    playFourDigitNumber $integer;
    return;
  }

  while {[string length $integer] > 0} {
    set len [string length $integer];
    if {$len == 1} {
      playMsg "Default" $integer;
      set integer "";
    } elseif {$len % 2 == 0} {
      playTwoDigitNumber [string range $integer 0 1];
      set integer [string range $integer 2 end];
    } else {
      playThreeDigitNumber [string range $integer 0 2];
      set integer [string range $integer 3 end];
    }
  }
}


#
# Zeg de tijd.
#
#   TIME_FORMAT=24: "veertien uur dertig", "negen uur".
#   TIME_FORMAT=12 (standaard): spreektaal, bijv. "vijf voor half drie",
#                               "kwart over negen", "twaalf uur".
#
proc playTime {hour minute} {
  set time_format [getConfigValue $::logic_name TIME_FORMAT 12]

  # Strip white space and leading zeros. Check ranges.
  if {[scan $hour "%d" hour] != 1 || $hour < 0 || $hour > 23} {
    error "playTime: Non digit hour or value out of range: $hour"
  }
  if {[scan $minute "%d" minute] != 1 || $minute < 0 || $minute > 59} {
    error "playTime: Non digit minute or value out of range: $minute"
  }

  if {$time_format == 24} {
    playMsg "Default" $hour;
    playMsg "Default" "hours";
    if {$minute != 0} {
      playMsg "Default" $minute;
    }
    playSilence 100;
    return;
  }

  # Anything not 24 falls back to the 12 hour spoken style
  set this_hour [expr {$hour % 12}];
  if {$this_hour == 0} {
    set this_hour 12;
  }
  set next_hour [expr {$this_hour % 12 + 1}];

  if {$minute == 0} {
    playMsg "Default" $this_hour;
    playMsg "Default" "hours";
  } elseif {$minute < 15} {
    playMsg "Default" $minute;
    playMsg "Default" "over";
    playMsg "Default" $this_hour;
  } elseif {$minute == 15} {
    playMsg "Default" "kwart";
    playMsg "Default" "over";
    playMsg "Default" $this_hour;
  } elseif {$minute < 30} {
    playMsg "Default" [expr {30 - $minute}];
    playMsg "Default" "voor";
    playMsg "Default" "half";
    playMsg "Default" $next_hour;
  } elseif {$minute == 30} {
    playMsg "Default" "half";
    playMsg "Default" $next_hour;
  } elseif {$minute < 45} {
    playMsg "Default" [expr {$minute - 30}];
    playMsg "Default" "over";
    playMsg "Default" "half";
    playMsg "Default" $next_hour;
  } elseif {$minute == 45} {
    playMsg "Default" "kwart";
    playMsg "Default" "voor";
    playMsg "Default" $next_hour;
  } else {
    playMsg "Default" [expr {60 - $minute}];
    playMsg "Default" "voor";
    playMsg "Default" $next_hour;
  }
  playSilence 100;
}


#
# Zeg een frequentie, bijv. 145725000 = "honderdvijfenveertig komma zeven
# twee vijf megahertz". De eenheden staan in Default.
#
#   fq -- The frequency in Hz
#
proc playFrequency {fq} {
  if {$fq < 1000} {
    set unit "Hz"
  } elseif {$fq < 1000000} {
    set fq [expr {$fq / 1000.0}]
    set unit "kHz"
  } elseif {$fq < 1000000000} {
    set fq [expr {$fq / 1000000.0}]
    set unit "MHz"
  } else {
    set fq [expr {$fq / 1000000000.0}]
    set unit "GHz"
  }
  playNumber [string trimright [string trimright [format "%.3f" $fq] "0"] "."]
  playMsg "Default" $unit
}
